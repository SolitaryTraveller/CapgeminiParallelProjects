package com.bank.dao;

import java.sql.Timestamp;
import java.util.Date;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.persistence.TypedQuery;
import javax.transaction.Transactional;


import org.springframework.stereotype.Repository;

import com.bank.user.bean.TransactionBean;
import com.bank.user.bean.UserBean;

@Repository("BankDao")
public class DaoClass implements DaoInterface {

	@PersistenceContext(name = "persistance")
	EntityManager conn;

	// this method create user account and data in map collection.
	@Transactional
	public int userAccountCreation(UserBean userbean) {

		conn.persist(userbean);
		return 1;

	}

	// this method show/display balance .
	@Transactional
	public String displayBalance(int accountId) {

		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(accountId));

		return "Balance is " + ub.getBalance();

	}

	@Transactional
	public int Login(int accountId, String accountPassword) {
		int flag = 0;

		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(accountId));
		if (ub.getAccountPassword().equals(accountPassword)) {
			flag = 1;
		} else {
			flag = 0;
		}
		return flag;

	}

	// this method is used for deposit amount.
	@Transactional
	public String Deposit(int accountId, int amount) {

		// Deposit Code
		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(accountId));
		int updatetBalance = ub.getBalance() + amount;
		ub.setBalance(updatetBalance);

		// Transaction COde
		TransactionBean tb = new TransactionBean();
		Date date = new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		tb.setAmount(amount);
		tb.setTransactionType("Deposit");
		tb.setTransactionDate(ts);
		tb.setUserbean(ub);

		conn.merge(ub);
		conn.persist(tb);
		// System.out.println(ub.getTransactions());

		return "Deposit Successfully Done";

	}

	// this method use for withdraw amount.
	@Transactional
	public String withDraw(int accountId, int amount) {

		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(accountId));
		int updatetBalance = ub.getBalance() - amount;
		ub.setBalance(updatetBalance);

		TransactionBean tb = new TransactionBean();

		Date date = new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		tb.setAmount(amount);
		tb.setTransactionType("Withdraw");
		tb.setTransactionDate(ts);
		tb.setUserbean(ub);

		conn.merge(ub);
		conn.persist(tb);

		return "Withdraw Successfully Done";

	}

	@Transactional
	public String fundTransfer(int sourceAccountId, int destinationAccountId, int amount) {

		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(sourceAccountId));
		int updatetBalance = ub.getBalance() - amount;
		ub.setBalance(updatetBalance);

		TransactionBean tb = new TransactionBean();

		Date date = new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		tb.setToAccountId(destinationAccountId);
		tb.setAmount(amount);
		tb.setTransactionType("Fund transfer to");
		tb.setTransactionDate(ts);
		tb.setUserbean(ub);

		UserBean ub2 = (UserBean) conn.find(UserBean.class, new Integer(destinationAccountId));
		int updatetBalance2 = ub2.getBalance() + amount;
		ub2.setBalance(updatetBalance2);

		TransactionBean tb2 = new TransactionBean();

		Date date2 = new Date();
		long time2 = date.getTime();
		Timestamp ts2 = new Timestamp(time2);
		tb2.setToAccountId(sourceAccountId);
		tb2.setAmount(amount);
		tb2.setTransactionType("Fund transfer from");
		tb2.setTransactionDate(ts2);
		tb2.setUserbean(ub2);

		conn.merge(ub);
		conn.merge(ub2);
		conn.persist(tb);
		conn.persist(tb2);

		return "Transfer Successfully Done";

	}

	// this method print the all transaction of logged in user.
	@Transactional
	public List<TransactionBean> printTransactions(int accountId) {

		@SuppressWarnings("unchecked")
		TypedQuery<TransactionBean> q = (TypedQuery<TransactionBean>) conn
				.createQuery("SELECT t FROM TransactionBean t where accountid = ?1").setParameter(1, accountId);

		List<TransactionBean> transaction = q.getResultList();

		return transaction;

	}

	// Validations

	// this method check account id is in collection or not.
	@Transactional
	public boolean validAccountId(int accountId) {

		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(accountId));
		if (ub != null) {
			return true;
		} else {
			return false;
		}

	}

	// this method check user have insufficient balance or not.
	@Transactional
	public boolean checkBalance(int accountId, int amount) {

		UserBean ub = (UserBean) conn.find(UserBean.class, accountId);
		if (ub.getBalance() >= amount) {
			return true;
		} else {
			return false;
		}

	}

}

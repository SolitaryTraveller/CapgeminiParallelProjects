package com.bank._SpringBoot_ParallelProject.services;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank._SpringBoot_ParallelProject.entities.TransactionBean;
import com.bank._SpringBoot_ParallelProject.entities.UserBean;
import com.bank._SpringBoot_ParallelProject.exceptions.GlobalException;
import com.bank._SpringBoot_ParallelProject.exceptions.InvalidAuthentication;
import com.bank._SpringBoot_ParallelProject.repository.ITransaction;
import com.bank._SpringBoot_ParallelProject.repository.IUser;

@Service("BankService")
public class BankServiceimpl implements BankServiceInterface {

	@Autowired
	private ITransaction transDao;

	@Autowired
	private IUser usersDao;

	public TransactionBean createTransactions(String transactionType, int amount) {
		TransactionBean tb = new TransactionBean();
		Date date = new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		tb.setAmount(amount);
		tb.setTransactionDate(ts);
		tb.setTransactionType(transactionType);

		return tb;

	}

	// Account Creation

	@Override
	public UserBean userAccountCreation(UserBean ub) {

		if (!ub.getMobileNumber().matches("[6-9][0-9]{9}")) {
			throw new GlobalException("Invalid Mobile Nunber");
		}
		return usersDao.save(ub);
	}

	@Override
	public UserBean Login(int accId, String accPassword) {

		if (usersDao.existsById(accId)) {
			Optional<UserBean> optionalUb = usersDao.findById(accId);
			UserBean dataBaseUb = optionalUb.get();
			if (dataBaseUb.getAccountPassword().equals(accPassword)) {
				return dataBaseUb;
			} else {
				throw new InvalidAuthentication("Password Not Matched");
			}
		}

		throw new InvalidAuthentication("Account Not Found");
	}

	// Display/Show Amount

	@Override
	public int displayBalance(int accId) {

		if (usersDao.existsById(accId)) {

			Optional<UserBean> optionalUb = usersDao.findById(accId);
			UserBean dataBaseUb = optionalUb.get();
			return dataBaseUb.getBalance();

		}

		return -1;
	}

	// Deposit Balance

	@Override
	public int depositBalance(UserBean ub) {
		if (usersDao.existsById(ub.getAccountId()) && ub.getBalance() > 0) {

			Optional<UserBean> optionalUb = usersDao.findById(ub.getAccountId());
			UserBean dataBaseUb = optionalUb.get();
			int total = ub.getBalance() + dataBaseUb.getBalance();
			dataBaseUb.setBalance(total);

			TransactionBean tb = createTransactions("Deposit", ub.getBalance());

			dataBaseUb.addTransactions(tb);

			transDao.save(tb);
			usersDao.save(dataBaseUb);

			return total;

		}

		return -1;
	}

	// Withdraw Balance

	@Override
	public int withdrawBalance(UserBean ub) {
		if (usersDao.existsById(ub.getAccountId())) {

			Optional<UserBean> optionalUb = usersDao.findById(ub.getAccountId());
			UserBean dataBaseUb = optionalUb.get();

			if (ub.getBalance() > dataBaseUb.getBalance()) {
				throw new GlobalException("Insufficient Balance");
			}

			int total = dataBaseUb.getBalance() - ub.getBalance();
			dataBaseUb.setBalance(total);

			TransactionBean tb = createTransactions("Withdraw", ub.getBalance());

			dataBaseUb.addTransactions(tb);
			transDao.save(tb);
			usersDao.save(dataBaseUb);

			return total;

		}

		return -1;

	}

	// Fund Transfer

	@Override
	public int fundTransfer(int accountId, UserBean ub) {

		boolean flag = false;
		boolean isTransferSucess = false;
		int totalAmt = 0;
		int globalId = ub.getAccountId();
		if (usersDao.existsById(ub.getAccountId())) {

			Optional<UserBean> optionalUb = usersDao.findById(ub.getAccountId());
			UserBean dataBaseUb = optionalUb.get();

			if (ub.getBalance() > dataBaseUb.getBalance()) {
				throw new GlobalException("Insufficient Balance");
			}

			int total = dataBaseUb.getBalance() - ub.getBalance();
			dataBaseUb.setBalance(total);

			totalAmt = total;
			flag = true;

			TransactionBean tb = createTransactions("Fund Transfer To", ub.getBalance());
			tb.setToAccountId(accountId);

			dataBaseUb.addTransactions(tb);
			transDao.save(tb);
			usersDao.save(dataBaseUb);

		}
		if (usersDao.existsById(accountId) && flag) {

			Optional<UserBean> optionalUb = usersDao.findById(accountId);
			UserBean dataBaseUb = optionalUb.get();
			int total = ub.getBalance() + dataBaseUb.getBalance();
			dataBaseUb.setBalance(total);
			usersDao.save(dataBaseUb);
			isTransferSucess = true;

			TransactionBean tb = createTransactions("Fund Transfer From", ub.getBalance());
			tb.setToAccountId(globalId);

			dataBaseUb.addTransactions(tb);
			transDao.save(tb);
			usersDao.save(dataBaseUb);

		}
		if (isTransferSucess) {
			return totalAmt;
		} else {
			return -1;
		}

	}

	// Transactions List

	@Override
	public Set<TransactionBean> transactionList(int accountId) {

		if (usersDao.existsById(accountId)) {
			Optional<UserBean> optionalUb = usersDao.findById(accountId);
			UserBean dataBaseUb = optionalUb.get();
			System.out.println(dataBaseUb.getTransactions());
			return dataBaseUb.getTransactions();
		}
		throw new GlobalException("account not found");
	}

}


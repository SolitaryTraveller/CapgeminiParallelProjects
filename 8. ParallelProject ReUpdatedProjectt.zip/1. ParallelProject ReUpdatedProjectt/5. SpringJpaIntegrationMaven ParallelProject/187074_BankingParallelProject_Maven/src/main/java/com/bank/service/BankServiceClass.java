package com.bank.service;

import com.bank.dao.DaoClass;
import com.bank.dao.DaoInterface;
import com.bank.exception.AccountNotFoundException;
import com.bank.exception.InsufficientFundException;
import com.bank.user.bean.TransactionBean;
import com.bank.user.bean.UserBean;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("BankService")
public class BankServiceClass implements BankServiceInterface {

	@Autowired
	private DaoInterface daoservice;

	
	Scanner sc = new Scanner(System.in);

	public String userAccountCreation(String accountPassword, String userName, long mobileNumber) {

		UserBean userbean = new UserBean();

		userbean.setName(userName);

		userbean.setAccountPassword(accountPassword);
		userbean.setMobileNumber(mobileNumber);

		int i = daoservice.userAccountCreation(userbean);
		if (i == 1) {
			return "Your Account is created with account ID " + userbean.getAccountId();
		} else {
			System.out.println("Something Went Wrong");
			return "There is some  problem in account creation";
		}
	}

	public String displayBalance(int accountId) {
		String s = daoservice.displayBalance(accountId);
		return s;
	}

	public String deposit(int accountId, int amount) {
		
		String s = daoservice.Deposit(accountId, amount);
		return s;
	}

	public String withDraw(int accountId, int amount) {
		String s = daoservice.withDraw(accountId, amount);
		return s;
	}

	public String fundTransfer(int sourceAccountId, int destinationAccountId, int amount) {
		String s = daoservice.fundTransfer(sourceAccountId, destinationAccountId, amount);
		return s;
	}

	public int Login(int accountId, String accountPassword) {
		int i = daoservice.Login(accountId, accountPassword);
		if (i == 1) {
			return 1;
		} else {
			return 0;
		}
	}

	public String printTransactions(int accountId) {
		// TODO Auto-generated method stub
		List<TransactionBean> hm = daoservice.printTransactions(accountId);

		Iterator i = hm.iterator();

		String s = "";
		while (i.hasNext()) {

			TransactionBean t = (TransactionBean) i.next();

			if (t.getToAccountId() != 0) {
				s = s + "\n" + "transaction ID = " + t.getTransactionId() + "\n Transaction Type = "
						+ t.getTransactionType() + " \n Date = " + t.getTransactionDate() + " \n account id = "
						+ t.getUserbean().getAccountId() + "\n amount = " + t.getAmount() + " \n to account id= "
						+ t.getToAccountId();
			} else {
				s = s + "\n" + "transaction ID = " + t.getTransactionId() + "\n Transaction Type = "
						+ t.getTransactionType() + " \n Date = " + t.getTransactionDate() + " \n account id = "
						+ t.getUserbean().getAccountId() + "\n amount = " + t.getAmount();
			}

		}

		return s;

		
	}
// Validation Methods
	public String Checkname(String name) {

		while (true) {

			try {
				if (name.matches("[A-Z a-z]{3,10}")) {
					return name;
				} else {

					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("------------ Error----------------");
				System.out.println("Please Enter Valid  Username Length Should be more than two digits");
				System.out.println("Enter again:[Enter exit for dashboard]");
				name = sc.nextLine();
				if (name.equals("exit")) {
					return "exit";
				}
			}
		}
	}

	// this method validate password.
	public String Checkpassword(String password) {
		while (true) {
			try {
				if (password.matches("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{4,16}$")) {
					return password;

				} else {
					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("Please Enter valid password Password should starts with Capital letter");
				System.out.println("Enter again:[Enter exit for dashboard]");
				password = sc.nextLine();
				if (password.equals("exit")) {
					return "exit";
				}
			}

		}
	}

	// this method validate user mobile number.
	public String CheckmobileNumber(String mobileNumber) {
		while (true) {
			try {
				if (mobileNumber.matches("[6-9][0-9]{9}")) {
					return mobileNumber;

				} else {
					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("Enter 10 digit  valid mobile number");
				System.out.println("Enter again");
				mobileNumber = sc.nextLine();
				if (mobileNumber.equals("exit")) {
					return "exit";
				}
			}

		}
	}

	// this method check user enter amount limit.(not greater than 999999).
	public String CheckamountLimit(String amount) {
		while (true) {
			try {
				if (amount.length() > 6 || amount.equals(0)) {
					throw new Exception();
				} else {
					return amount;
				}
			} catch (Exception ex) {
				System.out.println("Enter valid amount.(less than 999999)");
				System.out.println("Enter again");
				amount = sc.nextLine();
				if (amount.equals("exit")) {
					return "exit";
				}
			}
		}
	}

	// this method check if account id present in collection or not.

	public String validAccountId(String accountId) {
		char[] chars = accountId.toCharArray();
		StringBuilder sb = new StringBuilder();
		for (char c : chars) {
			if (!Character.isDigit(c)) {
				throw new AccountNotFoundException("Invalid Account Number");
			}
		}
		if (daoservice.validAccountId(Integer.parseInt(accountId))) {
			return accountId;
		} else {
			throw new AccountNotFoundException("Invalid Account Number");
		}

	}

	// this method check balance in user account..
	public String checkBalance(String accountId, String amount) {
		if (daoservice.checkBalance(Integer.parseInt(accountId), Integer.parseInt(amount))) { // Here we transfer amount
																								// to DAO class.
			return amount;
		} else {
			throw new InsufficientFundException("Insufficient amount");
		}

	}

}

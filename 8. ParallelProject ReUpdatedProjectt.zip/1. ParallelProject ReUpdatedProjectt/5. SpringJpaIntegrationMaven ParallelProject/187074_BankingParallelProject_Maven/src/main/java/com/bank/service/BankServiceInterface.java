package com.bank.service;

public interface BankServiceInterface {

	// These all are service methods
	String userAccountCreation(String accountPassword, String userName, long mobileNumber);

	int Login(int accountId, String accountPassword);

	String displayBalance(int accountId);

	String deposit(int accountId, int amount);

	String withDraw(int accountId, int amount);

	String fundTransfer(int sourceAccountId, int destinationAccountId, int amount);

	String printTransactions(int accountId);

	// these all are validation methods.
	String validAccountId(String accountId);

	String checkBalance(String accountId, String amount);

	String Checkname(String userName);

	String Checkpassword(String password);

	String CheckmobileNumber(String mobileNumber);

	String CheckamountLimit(String amount);
}
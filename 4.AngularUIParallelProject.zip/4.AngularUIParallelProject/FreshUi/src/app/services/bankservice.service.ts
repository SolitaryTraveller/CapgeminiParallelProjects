import { Injectable } from '@angular/core';
import { userModel } from '../models/userModel';
import { UserTransactions } from '../models/userTransactions';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {AuthServicesService} from './auth-services.service';


@Injectable({
  providedIn: 'root'
})


export class BankserviceService {

  http:HttpClient 
  authService:AuthServicesService
  registerUsers:userModel[] = []
  usersTransactions:UserTransactions[] = []

  currentUserAccId:number;
  currentUserAccPass:string;

  constructor(http:HttpClient,authService:AuthServicesService) {
    this.authService = authService;
    this.http = http;

   }

  setLogginDetails(){
    this.currentUserAccId = parseInt(this.authService.getToken());
  }
  
  convert(data:any){
    
      
      let d = new userModel(data.accountId,data.accountPassword,data.name,data.mobileNumber,data.balance)
      this.registerUsers.push(d);
      console.log(this.registerUsers)
    
  }



  RegisterUser(username:string,password:string,mobilenumber:string):Observable<any>{
    let jsonObj = {
      "name":username,
      "accountPassword":password,
      "mobileNumber":mobilenumber
    }
    let url = 'http://localhost:6969/Bank/create'

    return this.http.post(url,jsonObj);
    
  }

  LoginUser(accountid:number,password:string):Observable<any>{
    let url = 'http://localhost:6969/Bank/login/id/'+accountid+'/password/'+password;
    return this.http.get(url);
  }

  ShowBalance():Observable<any>{
    let accId = parseInt(this.authService.getToken());
    let url = "http://localhost:6969/Bank/balance/"+accId;
    return this.http.get(url);
   
  }

  DepositAmount(amount:any):Observable<any>{

    let url = "http://localhost:6969/Bank/deposit";
    let accId = parseInt(this.authService.getToken());
    let jsonObj = {
      "accountId":accId,
      "balance":amount
    }
    return this.http.put(url,jsonObj);

  }

  WithdrawAmount(amount:any):Observable<any>{

    let url = "http://localhost:6969/Bank/withdraw";
    let accId = parseInt(this.authService.getToken());
    let jsonObj = {
      "accountId":accId,
      "balance":amount
    }
    return this.http.put(url,jsonObj);
  }

  FundTransfer(accountid:any,amount:any):Observable<any>{
   
    let url = 'http://localhost:6969/Bank/fundtransfer/'+accountid;
    let accId = parseInt(this.authService.getToken())

    let jsonObj = {
      "accountId":accId,
      "balance":amount
    }

    return this.http.put(url,jsonObj);
    
  }



  PrintTransactions():Observable<any>{
    
    let accId = parseInt(this.authService.getToken())
    let url = 'http://localhost:6969/Bank/transactions/'+accId;

    return this.http.get(url);
    
  }



}

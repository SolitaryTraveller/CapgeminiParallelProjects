package com.bank.dao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.security.auth.login.AccountNotFoundException;

import com.bank.user.bean.UserBean;
import com.bank.user.bean.TransactionBean;

public class DaoClass implements DaoInterface {

	EntityManager conn;

	HashMap<String, UserBean> UserAccountData;

	public DaoClass() {
		UserAccountData = new HashMap<String, UserBean>();
	}

	// User Account Creation
	@Override
	public int userAccountCreate(UserBean userbean) {

		conn = DaoDatabaseConnection.getConnection();
		conn.getTransaction().begin();

		conn.persist(userbean);
		conn.getTransaction().commit();
		conn.close();
		return 1;

	}

	// Show Balance
	@Override
	public String showBalance(int accountId) {

		conn = DaoDatabaseConnection.getConnection();
		conn.getTransaction().begin();

		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(accountId));
		conn.getTransaction().commit();
		conn.close();
		return "your Balance is " + ub.getBalance();
		
	}

	// SignIn

	@Override
	public int Login(int accountId, String accountPassword) {
		int flag = 0;
		conn = DaoDatabaseConnection.getConnection();
		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(accountId));
		conn.close();
		if (ub.getAccountPassword().equals(accountPassword)) {
			flag = 1;
		} else {
			flag = 0;
		}
		return flag;

	}

	// Deposite
	@Override
	public String Deposit(int accountId, int amount) {

		// Deposit Code
		conn = DaoDatabaseConnection.getConnection();
		conn.getTransaction().begin();
		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(accountId));
		int updatetBalance = ub.getBalance() + amount;
		ub.setBalance(updatetBalance);

		// Transaction COde
		TransactionBean tb = new TransactionBean();
		Date date = new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		tb.setAmount(amount);
		tb.setTransactionType("Deposit");
		tb.setTransactionDate(ts);
		tb.setUserbean(ub);

		conn.merge(ub);
		conn.persist(tb);
		conn.getTransaction().commit();
		// System.out.println(ub.getTransactions());
		conn.close();
		return "Deposit Successfull";

	}

	// Withdraw Amount
	@Override
	public String withDraw(int accountId, int amount) {
		conn = DaoDatabaseConnection.getConnection();
		conn.getTransaction().begin();
		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(accountId));
		int updatetBalance = ub.getBalance() - amount;
		ub.setBalance(updatetBalance);

		TransactionBean tb = new TransactionBean();

		Date date = new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		tb.setAmount(amount);
		tb.setTransactionType("Withdraw");
		tb.setTransactionDate(ts);
		tb.setUserbean(ub);

		conn.merge(ub);
		conn.persist(tb);
		conn.getTransaction().commit();
		conn.close();
		return "Withdraw Successfull";

	}

	@Override
	public String fundTransfer(int sourceAccountId, int destinationAccountId, int amount)
			throws AccountNotFoundException {

		conn = DaoDatabaseConnection.getConnection();
		conn.getTransaction().begin();
		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(sourceAccountId));
		int updatetBalance = ub.getBalance() - amount;
		ub.setBalance(updatetBalance);

		TransactionBean tb = new TransactionBean();

		Date date = new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		tb.setToAccountId(destinationAccountId);
		tb.setAmount(amount);
		tb.setTransactionType("fund transfer to");
		tb.setTransactionDate(ts);
		tb.setUserbean(ub);

		UserBean ub2 = conn.find(UserBean.class, new Integer(destinationAccountId));
		if (ub2 == null) {
			throw new AccountNotFoundException("No account found for this account number");
		}
		int updatetBalance2 = ub2.getBalance() + amount;
		ub2.setBalance(updatetBalance2);

		TransactionBean tb2 = new TransactionBean();

		Date date2 = new Date();
		long time2 = date.getTime();
		Timestamp ts2 = new Timestamp(time2);
		tb2.setToAccountId(sourceAccountId);
		tb2.setAmount(amount);
		tb2.setTransactionType("fund transfer from");
		tb2.setTransactionDate(ts2);
		tb2.setUserbean(ub2);

		conn.merge(ub);
		conn.merge(ub2);
		conn.persist(tb);
		conn.persist(tb2);

		conn.getTransaction().commit();
		conn.close();
		return "Transfer Successfull";

	}

	// Current Users Trsansactions
	@Override
	public List<TransactionBean> printTransactions(int accountId) {

		conn = DaoDatabaseConnection.getConnection();
		conn.getTransaction().begin();

		TypedQuery<TransactionBean> q = (TypedQuery<TransactionBean>) conn
				.createQuery("SELECT j FROM TransactionBean j where accountid = ?1").setParameter(1, accountId);

		List<TransactionBean> transaction = q.getResultList();

		conn.getTransaction().commit();
		conn.close();
		return transaction;

	}

	// Validations

	// Accopunt Validation
	@Override
	public boolean validAccountId(int accountId) {

		conn = DaoDatabaseConnection.getConnection();
		UserBean ub = (UserBean) conn.find(UserBean.class, new Integer(accountId));
		conn.close();
		if (ub != null) {
			return true;
		} else {
			return false;
		}

	}

	// Balance Check
	@Override
	public boolean checkBalance(int accountId, int amount) {

		conn = DaoDatabaseConnection.getConnection();
		UserBean ub = (UserBean) conn.find(UserBean.class, accountId);
		conn.close();
		if (ub.getBalance() >= amount) {
			return true;
		} else {
			return false;
		}

	}

}

package com.capgemini.bank.exception;

///Exception throw when user's account id is not Valid/Found .

@SuppressWarnings("serial")
public class AccountNotFoundException extends RuntimeException {
	public AccountNotFoundException(String message) {

		super(message);
		System.out.println("Accound Not Exists..Please Provide Valid Account Number");
	}
}

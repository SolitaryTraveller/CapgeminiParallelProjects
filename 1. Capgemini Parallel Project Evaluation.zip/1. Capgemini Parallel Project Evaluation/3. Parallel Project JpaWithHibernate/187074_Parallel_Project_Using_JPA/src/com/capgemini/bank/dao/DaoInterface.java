package com.capgemini.bank.dao;

import java.util.HashMap;
import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import com.capgemini.bank.user.bean.TransactionBean;
import com.capgemini.bank.user.bean.UserBean;

public interface DaoInterface {
	
	
	// Service Methods

	int userAccountCreate(UserBean userbean);

	int Login(int accountId, String accountPassword);

	String showBalance(int accountId);

	String Deposit(int accountId, int amount);

	String withDraw(int accountId, int amount);

	String fundTransfer(int sourceAccountId, int destinationAccountId, int amount) throws AccountNotFoundException;

	List<TransactionBean> printTransactions(int accountId);

	// Validation methods
	
	
	boolean validAccountId(int accountId);

	boolean checkBalance(int accountId, int amount);

}

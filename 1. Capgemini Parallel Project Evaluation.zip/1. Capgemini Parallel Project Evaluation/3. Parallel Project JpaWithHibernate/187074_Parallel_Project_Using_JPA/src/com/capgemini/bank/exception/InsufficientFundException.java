package com.capgemini.bank.exception;

// exception throws when user have insufficient balance in his/her account.

@SuppressWarnings("serial")
public class InsufficientFundException extends RuntimeException{
	public InsufficientFundException(String message) {
		super(message);
		System.out.println("Insufficient Balance in Your Account");
		}
}

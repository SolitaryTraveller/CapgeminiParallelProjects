package com.capgemini.bank.dao;

import static org.junit.Assert.assertEquals;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.Test;

public class TestCase {
	
	//Test Case for LoginTest
	
	
	@Test
	public void LoginTest() {
		DaoClass dao = new DaoClass();
		int s = dao.Login(1, "Rahul55555");
		assertEquals(1, s);

	}
	
	
	// Test Case for BalanceCheck
	
	
	@Test
	public void showBalanceTest() {
		DaoClass dao = new DaoClass();
		String s = dao.showBalance(1);
		assertEquals("your Balance is 11", s);

	}
	
	// Test Case for DepositeCheck

	@Test
	public void testDepositebalance() {
		DaoClass dao = new DaoClass();
		String s = dao.Deposit(1, 100);
		assertEquals("Deposit Successfull", s);

	}
	
	// Test Case for WithdrawCheck

	@Test
	public void testWithdrawBalance() {
		DaoClass dao = new DaoClass();
		String s = dao.withDraw(1, 50);
		assertEquals("Withdraw Successfull", s);
	}
	
	// Test Case for TransferBalance

	@Test
	public void testTransferBalance() throws AccountNotFoundException {
		DaoClass dao = new DaoClass();
		String s = dao.fundTransfer(1, 2, 50);
		assertEquals("Transfer Successfull", s);

	}
}

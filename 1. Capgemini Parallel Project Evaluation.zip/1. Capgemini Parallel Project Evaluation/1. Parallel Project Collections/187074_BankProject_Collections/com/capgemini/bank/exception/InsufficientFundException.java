package com.capgemini.bank.exception;

// Exception throws when user have insufficient balance.

public class InsufficientFundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsufficientFundException(String message) {
		super(message);
		}
}

package com.bank._SpringBoot_ParallelProject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bank._SpringBoot_ParallelProject.entities.TransactionBean;

@Repository
public interface ITransaction extends JpaRepository<TransactionBean, Integer> {

}